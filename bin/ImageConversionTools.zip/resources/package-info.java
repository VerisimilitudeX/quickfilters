/**
 * Resource classes for Duke/Coursera course.
 */
package resources;
